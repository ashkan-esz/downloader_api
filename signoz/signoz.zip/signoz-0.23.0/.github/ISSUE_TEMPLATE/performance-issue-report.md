---
name: Performance issue report
about: Long response times, high resource usage? Ensuring that SigNoz is scalable
  is our top priority
title: ''
labels: ''
assignees: ''

---

## In what situation are you experiencing subpar performance?

*Please describe.*

## How to reproduce

1.
2.
3.

## Your Environment

- [ ] Linux
- [ ] Mac
- [ ] Windows

Please provide details of OS version etc.

## Additional context



#### *Thank you* for your performance issue report – we want SigNoz to be blazing fast!
