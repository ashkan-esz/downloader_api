const apiV1 = '/api/v1/';

export const apiV2 = '/api/v2/';
export const apiV3 = '/api/v3/';
export const apiAlertManager = '/api/alertmanager';

export default apiV1;
