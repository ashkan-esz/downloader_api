import styled from 'styled-components';

export const ContainerStyled = styled.div`
	margin-bottom: 0.3rem;
`;
