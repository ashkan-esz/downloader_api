import { Space } from 'antd';
import styled from 'styled-components';

export const EditorContainer = styled.div`
	margin-top: 2rem;
`;

export const FooterContainer = styled(Space)`
	display: flex;
`;
