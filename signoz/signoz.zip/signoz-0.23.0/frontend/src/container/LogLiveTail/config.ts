export const TIME_PICKER_OPTIONS = [
	{
		value: 5,
		label: '5m',
	},
	{
		value: 15,
		label: '15m',
	},
	{
		value: 30,
		label: '30m',
	},
	{
		value: 60,
		label: '1hr',
	},
	{
		value: 360,
		label: '6hrs',
	},
	{
		value: 720,
		label: '12hrs',
	},
];
