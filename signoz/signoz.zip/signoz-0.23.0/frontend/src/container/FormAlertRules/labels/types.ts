export interface ILabelRecord {
	key: string;
	value: string;
}

export interface IOption {
	label: string;
	value: string;
}
