import { Select } from 'antd';
import styled from 'styled-components';

export const StyledSelect = styled(Select)`
	border-radius: 4px;
`;
