import ChQuerySection from './ChQuerySection';

export default ChQuerySection;
