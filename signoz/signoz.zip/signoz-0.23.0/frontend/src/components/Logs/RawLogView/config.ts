import { CSSProperties } from 'react';

export const rawLineStyle: CSSProperties = {};
