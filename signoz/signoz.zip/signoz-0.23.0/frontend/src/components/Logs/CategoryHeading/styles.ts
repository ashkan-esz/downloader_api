import { Typography } from 'antd';
import styled from 'styled-components';

export const CategoryHeadingText = styled(Typography.Text)`
	font-size: 0.8rem;
`;
