export const isValidLogField = (value: never): boolean => value !== undefined;
