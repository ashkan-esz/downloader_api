import { Typography } from 'antd';
import styled from 'styled-components';

export const Value = styled(Typography)`
	font-size: 2.5vw;
	text-align: center;
`;
