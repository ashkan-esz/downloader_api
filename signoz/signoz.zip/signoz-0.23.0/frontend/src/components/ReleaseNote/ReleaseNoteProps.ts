export default interface ReleaseNoteProps {
	path?: string;
	release?: string;
}
