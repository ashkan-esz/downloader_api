export type TabLabelProps = {
	isDisabled: boolean;
	label: string;
	tooltipText?: string;
};
