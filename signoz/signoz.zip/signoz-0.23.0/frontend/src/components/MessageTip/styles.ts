import { Alert } from 'antd';
import styled from 'styled-components';

export const StyledAlert = styled(Alert)`
	align-items: center;
`;
