export const style = { fontSize: '1rem' };
