import { FlattenSimpleInterpolation } from 'styled-components';

export interface IStyledClass {
	styledclass?: FlattenSimpleInterpolation[];
}
