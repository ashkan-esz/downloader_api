export const defaultText = 'Ah, seems like we reached a dead end!';
