const SOMETHING_WENT_WRONG = 'Something went wrong';

const getVersion = 'version';

export { getVersion, SOMETHING_WENT_WRONG };
