export const SKIP_ONBOARDING = 'skip_onboarding';
